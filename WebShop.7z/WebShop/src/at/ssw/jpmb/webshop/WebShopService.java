package at.ssw.jpmb.webshop;

import javax.jws.WebMethod;
import javax.jws.WebService;

@WebService
public class WebShopService {

	private final WebShop impl;
	
	public WebShopService(WebShop impl) {
		this.impl = impl;
	}
	
	@WebMethod
	public String getNameByID(int id) {
		try {
			return impl.get(id).name;
		} catch(Throwable t) {
			t.printStackTrace(System.err);
			return null;
		}
	}
	
	@WebMethod
	public double getPriceByID(int id) {
		try {
			return impl.get(id).price;
		} catch(Throwable t) {
			t.printStackTrace(System.err);
			return -1;
		}
	}
	
	@WebMethod
	public String getDescriptionByID(int id) {
		try {
			return impl.getDescription(id);
		} catch(Throwable t) {
			t.printStackTrace(System.err);
			return null;
		}

	}
	
	@WebMethod
	public int getIDByName(String name) {
		try {
			return impl.search(name);
		} catch(Throwable t) {
			t.printStackTrace(System.err);
			return -1;
		}
	}
	
}
