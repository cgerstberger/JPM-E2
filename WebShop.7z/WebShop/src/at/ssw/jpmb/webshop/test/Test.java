package at.ssw.jpmb.webshop.test;

import at.ssw.jpmb.webshop.WebShop;
import at.ssw.jpmb.webshop.WebShopService;

public class Test {

	public static void main(String[] args) {
		WebShopService service = new WebShopService(new WebShop());
		
		long start = System.currentTimeMillis();
		for(int i = 0; i < 100_000; i++) {
			service.getNameByID(2);
		}
		System.out.println((System.currentTimeMillis() - start) + "ms");

		start = System.currentTimeMillis();
		for(int i = 0; i < 100_000; i++) {
			service.getIDByName("Item -1");
		}
		System.out.println((System.currentTimeMillis() - start) + "ms");

		start = System.currentTimeMillis();
		for(int i = 0; i < 100_000; i++) {
			service.getDescriptionByID(3);
		}
		System.out.println((System.currentTimeMillis() - start) + "ms");
	}
	
}
