package at.ssw.jpmb.webshop;

import java.io.File;

public interface Constants {

	public static final String DB_FOLDER = ".db" + File.separator;
	
}
