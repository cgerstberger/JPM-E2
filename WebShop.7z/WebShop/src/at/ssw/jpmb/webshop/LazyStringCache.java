package at.ssw.jpmb.webshop;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

public class LazyStringCache {

	private static final Map<File, LazyString> CACHE = new HashMap<>();

	public static LazyString get(File file) {
		synchronized (CACHE) {
			LazyString cached = CACHE.get(file);
			if (cached == null) {
				cached = new LazyString(file);
				CACHE.put(file, cached);
			}
			return cached;
		}
	}
}