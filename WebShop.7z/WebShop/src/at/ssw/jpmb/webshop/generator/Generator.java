package at.ssw.jpmb.webshop.generator;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import at.ssw.jpmb.webshop.Constants;

public class Generator {

	public static void main(String[] args) throws IOException {
		new File(Constants.DB_FOLDER).mkdirs();
		int id = 0;
		for(int i = 0; i < 1000; i++) {
			File file = new File(Constants.DB_FOLDER + File.separator + i + ".items");
			try(BufferedWriter out = new BufferedWriter(new FileWriter(file))) {
				for(int j = 0; j < i % 5; j++) {
					int myid = id++;
					out.write("id=" + myid + "\n");
					out.write("name=Item " + myid + "\n");
					out.write("price=" + myid + ".99\n");
					try(BufferedWriter descOut = new BufferedWriter(new FileWriter(Constants.DB_FOLDER + File.separator + myid + ".description"))) {
						for(int k = 0; k < 1024 * 1024; k++) {
							descOut.write(myid);
						}
					}
				}
			}
		}
	}

}
