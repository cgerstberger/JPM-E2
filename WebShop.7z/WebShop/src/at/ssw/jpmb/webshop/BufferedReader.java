package at.ssw.jpmb.webshop;

import java.io.Closeable;
import java.io.EOFException;
import java.io.IOException;
import java.io.Reader;

public class BufferedReader implements Closeable {

	private final Reader in;
	
	public BufferedReader(Reader in) {
		this.in = in;
	}
	
	public String readLine() throws IOException {
		StringBuilder result = new StringBuilder();
		int c = in.read();
		if(c == -1) throw new EOFException();
		while(c >= 0 && c != '\n') {
			result.append((char) c);
			c = in.read();
		}
		return result.toString();
	}

	@Override
	public void close() throws IOException {
		in.close();
	}	
}
