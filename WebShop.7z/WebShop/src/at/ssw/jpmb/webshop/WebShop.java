package at.ssw.jpmb.webshop;

import java.io.EOFException;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class WebShop {

	private final Object lock = new Object();
	private final Map<Integer, Item> items = new HashMap<>();
	private final Map<String, Integer> idMap = new HashMap<>();
	
	public WebShop() {
		load();
	}

	private void load() {
		for(File file : new File(Constants.DB_FOLDER).listFiles()) {
			if(file.getName().endsWith(".items")) {
				try(BufferedReader in = new BufferedReader(new FileReader(file))) {
					String line = in.readLine();
					int id = 0;
					String name = null;
					double price = 0;
					for(;;) {
						line = line.trim();
						if(line.isEmpty()) continue;
						int index = line.indexOf('=');
						assert index > 0;
						String key = line.substring(0, index);
						String value = line.substring(index + 1, line.length());
						switch(key) {
							case "id": id = Integer.parseInt(value); break;
							case "name": name = value; break;
							case "price": price = Double.parseDouble(value); /* fallthrough */
							default:
								items.put(id, new Item(id, name, price));
								idMap.put(name, id);
						}
						line = in.readLine();
					}
				} catch (FileNotFoundException e) {
					assert false;
					e.printStackTrace(System.err);
				} catch (EOFException e) {
					//file is at its end
				} catch (IOException e) {
					e.printStackTrace(System.err);
				}
			}
		}
	}

	public Item get(int id) {
		synchronized(lock) {
			return items.get(id);
		}
	}

	public int search(String name) {
		synchronized(lock) {
			if(idMap.containsKey(name))
				return idMap.get(name);
//			for(int id : items.keySet()) {
//				if(items.get(id).name.equals(name)) {
//					return id;
//				}
//			}
			return -1;
		}
	}

	public String getDescription(int id) {
		return LazyStringCache.get(new File(getItemDescriptionFileName(id))).toString();
	}
	
	private String getItemDescriptionFileName(int id) {
		return Constants.DB_FOLDER + File.separator + id + ".description";
	}
	
}
