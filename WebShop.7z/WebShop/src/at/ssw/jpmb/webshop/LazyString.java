package at.ssw.jpmb.webshop;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;

public class LazyString {

	private final File file;
	
	private int accesses;
	private String cached;
	
	public LazyString(File file) {
		this.file = file;
		accesses = 0;
		cached = null;
	}
	
	public boolean equals(Object other) {
		if(other == null) return false;
		if(!getClass().equals(other.getClass())) return false;
		LazyString that = (LazyString) other;
		return this.file.equals(that.file) && (this.cached == that.cached || cached != null && cached.equals(that.cached));
	}
	
	public int hashCode() {
		return file.hashCode();
	}
	
	public String toString() {
		accesses++;
		if(cached != null) {
			return cached;
		}
		try(Reader in = new FileReader(file)) {
			StringBuilder builder = new StringBuilder();
			char[] buffer = new char[1024];
			for(int read = in.read(buffer); read > 0; read = in.read(buffer)) {
				builder.append(buffer, 0, read);
			}
			String value = builder.toString();
			if(accesses >= 10) {
				cached = value;
			}
			return value;
		} catch(IOException ioe) {
			throw new RuntimeException(ioe);
		}
	}

	public long getCachedSize() {
		return cached != null ? cached.length() : 0;
	}
	
}
